Github Repository Link: https://github.com/kracr/owl2bench


(Note: Please note that all the other required details such as License, README, experiments etc that are given below are already present (in more detail) in our Github repository (link shared above). Due to size contraint, jar files could not be uploaded here. )


License: Apache License 2.0



'Supplementary Material' Directory Structure:

1) Experiments

--------->README :  Details about the experiments performed.


--------->Scripts for Dataset generation used in the paper: main.sh can be run at once for all the experiments (except GraphDB query execution).

2) License File: Apache License 2.0


3) README: The README file present in this 'Supplementary Material' directory is a copy of the README file from our 'Project repository' (Link given at the top). It contains details about our benchmark 'OWL2Bench' and code-usage instrucation. For further details about the code and experiments, it points to two other directories present in the repository: OWL2Bench and Experiments. Each of these directories have a separate README file.
--------->The OWL2Bench is a java source code directory that generates the varying size datasets (TBox + ABox) to compare the reasoning and querying performance of OWL 2 Reasoners
--------->The Experiments folder consists of some codes for reasoner evaluation and the README file inside it consists of all the details that are required to replicate the experiments that were reported in the paper. 
